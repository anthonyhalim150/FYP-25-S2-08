import React from "react";

const Events = () => {
  return (
    <div className="events-container">
      <h1>Upcoming Events</h1>
      <p>List of all upcoming events...</p>
    </div>
  );
};

export default Events;
