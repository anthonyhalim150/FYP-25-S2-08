import React from "react";

const Leaderboard = () => {
  return (
    <div className="leaderboard-container">
      <h1>Leaderboard</h1>
      <ol>
        <li>4789</li>
        <li>4632</li>
        <li>4580</li>
        <li>4597</li>
        <li>4501</li>
      </ol>
    </div>
  );
};

export default Leaderboard;
